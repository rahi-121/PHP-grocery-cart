<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $conn = mysqli_connect("localhost", "root", "", "dbsc");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());

    }

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $email;
            header("Location: index.php"); // Redirect to homepage after login
            exit();
        } else {
            $error = "Invalid email or password!";
        }
    } else {
        $error = "Invalid email or password!";
    }

    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Sign In</title>
</head>
<body>
    <div class="signin-container">
        <h2>Login</h2>
        <form action="signin.php" method="POST">
            <input type="email" name="email" placeholder="Enter email" required>
            <input type="password" name="password" placeholder="Enter password" required>
            <div class="checkbox-container">
                <input type="checkbox" id="showPassword" onclick="togglePassword()">
                <label for="showPassword">Show Password</label>
            </div>
            <input type="submit" value="Sign In">
        </form>
        <a href="forgot-password.php" class="forgot-link">Forgot Username / Password?</a><br>
        <a href="register.php" class="register-link">Don't have an account? Sign up.</a>
    </div>
    <script>
        function togglePassword() {
            var passwordField = document.querySelector('input[name="password"]');
            passwordField.type = passwordField.type === "password" ? "text" : "password";
        }
    </script>
</body>
</html>